'use client'

export default function BoardSimpleTestPage() {
  return (
    <div className="p-8">
      <h1 className="text-2xl font-bold mb-4">Simple Test Board</h1>
      <div className="p-4 bg-green-100 text-green-800 rounded">
        This page is working! Client-side JavaScript is executing.
      </div>
    </div>
  )
}
